
CREATE FUNCTION multiplica(val1 integer, val2 integer)
RETURNS integer AS $$
BEGIN
RETURN val1 * val2;
END;
$$ LANGUAGE plpgsql;

SELECT multiplica (2,3);